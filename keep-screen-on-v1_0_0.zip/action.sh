#!/system/bin/sh
T=2147483647
F="$MODDIR/prev"
cur=$(settings get system screen_off_timeout)
if [ "$cur" = "$T" ]; then
  p=$(cat "$F" 2>/dev/null)
  settings put system screen_off_timeout "${p:-60000}"
  : > "$MODDIR/off"
  echo "Keep screen on: OFF"
else
  case $cur in ''|*[!0-9]*) cur=60000;; esac
  echo "$cur" > "$F"
  rm -f "$MODDIR/off"
  settings put system screen_off_timeout "$T"
  echo "Keep screen on: ON"
fi
echo "Timeout: $(settings get system screen_off_timeout) ms"
