#!/system/bin/sh
[ -f "$MODDIR/off" ] && exit 0
cur=$(settings get system screen_off_timeout)
[ "$cur" = 2147483647 ] && exit 0
case $cur in ''|*[!0-9]*) cur=60000;; esac
echo "$cur" > "$MODDIR/prev"
settings put system screen_off_timeout 2147483647
